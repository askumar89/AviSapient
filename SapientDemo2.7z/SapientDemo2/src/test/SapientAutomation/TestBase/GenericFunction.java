package TestBase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class GenericFunction {
	
	
 static	WebDriver driver = new FirefoxDriver();
 
 
 @BeforeTest
 public void LandingToThePage()
 {
	 System.setProperty("webdriver.firefox.marionette","C:\\Users\\abhkumar28\\Downloads\\geckodriver-v0.24.0-win64.exe");
		//System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null");
	    //comment the above 2 lines and uncomment below 2 lines to use Chrome
		//System.setProperty("webdriver.chrome.driver","G:\\chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
 	
     String baseUrl = "http://demo.guru99.com/test/newtours/";
    

     // launch Fire fox and direct it to the Base URL
     driver.get(baseUrl);

     // get the actual value of the title
   
 }
 
 
 @AfterClass
 public void CloseWindow()
 {
	 
	 driver.close();
 }

}
