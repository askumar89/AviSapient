package appPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import objectRepository.CollectionOFObjects;

public class loginPage implements  CollectionOFObjects {
	
	
	
	WebDriver driver;
	
	 @FindBy(name= CollectionOFObjects.login.username)
      private   WebElement user99GuruName;
	
	 @FindBy(name= CollectionOFObjects.login.Password)
	 private  WebElement user99GuruPassword;
	 
	 
	 @FindBy(name= CollectionOFObjects.login.BtnSubmit)
	 private   WebElement user99GuruBtn;
	
	
	 @FindBy(name= CollectionOFObjects.login.LoginPageObject)
	 private   WebElement Loginpageobject;
	 
	public WebElement getLoginpageobject() {
		return Loginpageobject;
	}


	public WebElement getUser99GuruName() {
		return user99GuruName;
	}


	public WebElement getUser99GuruPassword() {
		return user99GuruPassword;
	}


	public WebElement getUser99GuruBtn() {
		return user99GuruBtn;
	}

	public loginPage(WebDriver driver){

     this.driver = driver;

        //This initElements method will create all WebElements
       PageFactory.initElements(driver, this);

    }
	
	
	public void login()
	{
		
		 getUser99GuruName().sendKeys("abhishek");
		 getUser99GuruPassword().sendKeys("abhkumar89");
		 getUser99GuruBtn().click();
		
		
	}
	
}
