package appTests;


import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import appPages.loginPage;

public class SapientLoginTest extends loginPage{
	
	
	loginPage page;
	
	
	
	public SapientLoginTest(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}



	@Test(priority =1)
	public void TC_01VerifyPage()
	{
		 String expectedTitle = "Welcome: Mercury Tours";
	     String actualTitle = "08030636297";

        /*
         * compare the actual title of the page with the expected one and print
         * the result as "Passed" or "Failed"
         */
        if (actualTitle.contentEquals(expectedTitle)){
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed");
        }
       
        
	}
	
	
	
	@Test(priority =2)
	public void TC_02LoginPage()
	{
	login();
	Assert.assertEquals(getLoginpageobject().isDisplayed(),"We have reached in login page", "We have reached in login page");

}
}