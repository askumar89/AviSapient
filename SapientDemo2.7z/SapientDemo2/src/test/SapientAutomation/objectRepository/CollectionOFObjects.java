package objectRepository;

public interface CollectionOFObjects {
	
	public interface login
	{
		
		String username = "//lib[@id='idname']";
	    String Password = "//lib[@id='idname']";
		String BtnSubmit = "//lib[@id='idname']";
		String LoginPageObject = "//lib[@id='idname']";
		
		
	}
	
	
	public interface Signup
	{
        String username = "//lib[@id='idname']";
	    String Password = "//lib[@id='idname']";
		String BtnSubmit = "//lib[@id='idname']";
	}
	
	
	public interface Payment
	{
        String username = "//lib[@id='idname']";
		String Password = "//lib[@id='idname']";
		String BtnSubmit = "//lib[@id='idname']";
	}
	
	
	

}
